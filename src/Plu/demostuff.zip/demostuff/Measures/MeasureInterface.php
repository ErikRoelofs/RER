<?php

interface MeasureInterface
{

    public function calculate($item);

}