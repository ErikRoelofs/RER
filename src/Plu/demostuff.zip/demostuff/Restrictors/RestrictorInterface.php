<?php

interface RestrictorInterface
{

    public function relevant($item);

} 